---
name: 测试
description: zip 导入的 skill
---
这是正文内容