---
name: 多文件
description: 目录结构 skill
---
这是主入口正文。