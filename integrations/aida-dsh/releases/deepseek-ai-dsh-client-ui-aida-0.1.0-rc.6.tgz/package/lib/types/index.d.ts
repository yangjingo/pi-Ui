/** Host loader entry for the installable AIDA Web bundle; behavior stays browser-only. */
/** Provides no host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map