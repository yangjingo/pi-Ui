/**
 * Pure workspace-file helpers for the AIDA Canvas: tree flattening, query
 * filtering, path utilities, and binary payload conversion. No React, no
 * transport — the panel and the tree render from these shapes only.
 */
import type { WorkspaceFileKind, WorkspaceFileNode } from '@deepseek-ai/dsh-api-remotes/client';
/**
 * Flatten a listing tree to its leaf files.
 * @param nodes - recursive Workspace nodes.
 * @param result - accumulator used by recursive calls.
 * @returns the leaf file nodes in tree order.
 */
export declare function listFiles(nodes: readonly WorkspaceFileNode[], result?: WorkspaceFileNode[]): WorkspaceFileNode[];
/**
 * Count files (leaves) under a listing.
 * @param nodes - recursive Workspace nodes.
 * @returns the number of non-folder nodes.
 */
export declare function countFiles(nodes: readonly WorkspaceFileNode[]): number;
/**
 * Read the last path segment.
 * @param path - slash- or backslash-separated path.
 * @returns the final segment without trailing separators.
 */
export declare function basename(path: string): string;
/**
 * Read the parent directory of a path.
 * @param path - Workspace-relative path.
 * @returns the parent path, or an empty string for a top-level file.
 */
export declare function parentPath(path: string): string;
/**
 * Filter a tree case-insensitively; matching folders remain in the result.
 * @param nodes - recursive Workspace nodes.
 * @param query - path/name substring.
 * @returns a copied tree containing only matching branches.
 */
export declare function filterFileTree(nodes: readonly WorkspaceFileNode[], query: string): WorkspaceFileNode[];
/**
 * Flatten the visible leaf paths of a tree in render order, honoring the
 * collapsed set (the row order a shift+click range selection follows).
 * @param nodes - recursive Workspace nodes (already filtered).
 * @param collapsed - folder paths the user collapsed.
 * @returns the visible file paths in row order.
 */
export declare function visiblePathsOf(nodes: readonly WorkspaceFileNode[], collapsed: ReadonlySet<string>): string[];
/**
 * Decide whether a node has a source form the Canvas can edit: plain text
 * files and SVG documents (the host classifies SVG as an image, but its
 * source is UTF-8 text the canvas edits and writes back).
 * @param node - selected Workspace node, when any.
 * @returns true for text files and SVG documents.
 */
export declare function isSourceEditable(node: WorkspaceFileNode | undefined): boolean;
/**
 * Convert a file kind to its stable label.
 * @param kind - Workspace file kind.
 * @returns the corresponding lowercase label.
 */
export declare function kindLabel(kind: WorkspaceFileKind): string;
/**
 * Decode a base64 payload into a browser Blob.
 * @param base64 - encoded bytes.
 * @param contentType - MIME type assigned to the Blob.
 * @returns the decoded Blob.
 */
export declare function base64ToBlob(base64: string, contentType: string): Blob;
/**
 * Decode a base64 payload into UTF-8 text (an SVG read arrives as base64
 * because the host classifies SVG as an image).
 * @param base64 - encoded bytes.
 * @returns the decoded text, or an empty string when the payload is invalid.
 */
export declare function base64ToText(base64: string): string;
/**
 * Encode UTF-8 text as a base64 payload (the SVG preview consumes base64,
 * so a saved source is re-encoded locally to refresh the rendered image).
 * @param text - source text.
 * @returns the encoded payload.
 */
export declare function textToBase64(text: string): string;
/**
 * Parse a delimited table (RFC-4180 quoting: double quotes quote a field,
 * doubled quotes escape one; CRLF and LF both end rows). A trailing newline
 * does not add an empty row, and blank rows (every field empty) are dropped.
 * @param text - the raw table text.
 * @param delimiter - field separator (`,` or `\t`).
 * @returns the parsed rows.
 */
export declare function parseCsv(text: string, delimiter: string): string[][];
/**
 * Encode bytes as base64 without a Buffer dependency.
 * @param bytes - bytes to encode.
 * @returns the base64 payload.
 */
export declare function bytesToBase64(bytes: Uint8Array): string;
/**
 * Trigger a browser download for a Blob.
 * @param blob - content to download.
 * @param filename - suggested download name.
 */
export declare function saveBlobAs(blob: Blob, filename: string): void;
//# sourceMappingURL=files.d.ts.map