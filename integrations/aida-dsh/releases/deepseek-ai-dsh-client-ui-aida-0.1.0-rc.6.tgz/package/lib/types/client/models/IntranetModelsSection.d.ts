/**
 * AIDA intranet-models settings section: the preset roster with one-click
 * install. Each card shows the provider name, deployment description, default
 * endpoint, and model count; installing performs the same `settings.mutate`
 * the Models page's custom-provider card does, after which the provider and
 * its models appear in the model picker. Endpoint defaults are loopback and
 * are edited for the intranet host in the Models page after install.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
import type { IntranetModelsController } from './intranet-store.ts';
/** Injected face of the section: the install controller + its store hook. */
export interface IntranetModelsInjected {
    controller: IntranetModelsController;
    hooks: {
        /** Install state (status, writable, taken routes, busy). */
        intranetModels: IntranetModelsController['store'];
    };
}
/** Full composed props of the settings-section registration. */
export type IntranetModelsSectionProps = PropsRuntime<'settings.section'> & InjectFace<IntranetModelsInjected> & PropsLocale<typeof NS>;
/** Render the AIDA intranet-models preset roster. */
export declare function IntranetModelsSection({ useIntranetModels, controller, t }: IntranetModelsSectionProps): import("react").JSX.Element;
//# sourceMappingURL=IntranetModelsSection.d.ts.map