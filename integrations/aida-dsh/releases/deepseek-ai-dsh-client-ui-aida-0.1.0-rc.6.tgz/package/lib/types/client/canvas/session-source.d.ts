/**
 * Stable observable of the current session's conversation snapshot, for the
 * root-scoped Canvas drawer seat (`shell.overlay` has no session scope). The
 * source object is stable for the entry's lifetime; it re-resolves the
 * current session binding whenever the session list changes and re-emits when
 * the resolved snapshot changes. The apply body registers the dispose hook on
 * the fiber.
 */
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConversationSnapshot, ISessions } from '@deepseek-ai/dsh-client-runtime/client';
/** Stable uSES source of the current session's conversation snapshot. */
export interface CurrentSessionSource extends HostObservable<ConversationSnapshot | undefined> {
    /** Release the session-list subscription (wire into the fiber's effect). */
    dispose(): void;
}
/**
 * Create the current-session conversation source.
 * @param sessions - the runtime sessions face (`ctx.sessions`).
 * @returns a stable observable; call `dispose` when the owning fiber ends.
 */
export declare function createCurrentSessionSource(sessions: ISessions): CurrentSessionSource;
//# sourceMappingURL=session-source.d.ts.map