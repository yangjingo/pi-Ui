/**
 * File preview surface of the AIDA Canvas: formatted text (markdown, HTML,
 * mermaid, and SVG — each with a plain-textarea edit mode; SVG edits the
 * UTF-8 source decoded from the base64 read), generic text, image, PDF,
 * Office, and binary download. The panel feeds it the fetched workspace-file
 * read result; it never performs transport itself.
 */
import type { WorkspaceFileNode, WorkspaceFileRead } from '@deepseek-ai/dsh-api-remotes/client';
import type { AidaKey } from '../locales.ts';
import { type CanvasFileFormat } from './formats.ts';
/** Locale seat shape the preview consumes (the panel's own `t`). */
export type CanvasTranslate = (key: AidaKey, params?: Record<string, string>) => string;
export interface FilePreviewProps {
    /** The file being previewed. */
    node: WorkspaceFileNode;
    /** Render format for text files (derived from the extension). */
    format: CanvasFileFormat;
    /** Fetched content; null while loading or after a failed fetch. */
    read: WorkspaceFileRead | null;
    /** Fetch error message, shown when read is null and the fetch failed. */
    error: string | null;
    /** Whether the canvas is in edit mode for this file. */
    editing: boolean;
    /** Edit buffer (only meaningful while editing). */
    buffer: string;
    /** Edit-buffer change callback. */
    onBufferChange: (value: string) => void;
    /** Whether a save is in flight. */
    saving: boolean;
    /** Trigger a save of the current buffer. */
    onSave: () => void;
    /** Localized copy. */
    t: CanvasTranslate;
}
/** Render the preview body for one file kind. */
export declare function FilePreview({ node, read, error, editing, buffer, format, onBufferChange, saving, onSave, t }: FilePreviewProps): import("react").JSX.Element;
//# sourceMappingURL=preview.d.ts.map