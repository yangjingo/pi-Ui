/**
 * AIDA intranet model presets: a curated set of OpenAI-compatible provider
 * profiles for common intranet/local model servers (Ollama, vLLM, One API
 * gateways, LM Studio). Each preset installs with ONE `settings.mutate` into
 * the `llm-pi-ai` namespace at `providers.<route>` — the same write the
 * Models page's custom-provider card performs — after which the provider and
 * its models appear in the model picker. Base URLs default to loopback and
 * the user edits them for their intranet host in the Models page after
 * install.
 */
import type { AidaKey } from '../locales.ts';
/** The settings namespace hand-declared providers are written into. */
export declare const LLM_PROVIDER_NS = "llm-pi-ai";
/** One default model of a preset. */
export interface IntranetModelPresetModel {
    /** Model id as the server exposes it. */
    id: string;
    /** Optional display name. */
    name?: string;
    /** Optional context-window capacity (tokens). */
    contextWindow?: number;
    /** Optional max-output capacity (tokens). */
    maxTokens?: number;
}
/** One installable intranet provider preset. */
export interface IntranetModelPreset {
    /** Route id (also the settings key and credential-name stem). */
    route: string;
    /** Display name shown on the install card and in the model picker. */
    displayName: string;
    /** Locale key of the one-line deployment description. */
    descriptionKey: AidaKey;
    /** Wire protocol the preset speaks (OpenAI-compatible by default). */
    protocol: string;
    /** Default endpoint; the user adjusts it for their intranet host. */
    baseURL: string;
    /** Default models the server is expected to serve. */
    models: readonly IntranetModelPresetModel[];
}
/** The curated preset roster. */
export declare const INTRANET_MODEL_PRESETS: readonly IntranetModelPreset[];
/**
 * Build the settings value written for one preset.
 * @param preset - selected intranet provider preset.
 * @returns a detached provider profile matching the custom-provider form.
 */
export declare function providerProfileFor(preset: IntranetModelPreset): {
    displayName: string;
    api: string;
    baseURL: string;
    models: readonly IntranetModelPresetModel[];
};
/**
 * Check whether a provider route is already declared.
 * @param namespaceValue - current llm-pi-ai namespace value.
 * @param route - provider route id.
 * @returns true when the providers object owns that route.
 */
export declare function isRouteInstalled(namespaceValue: unknown, route: string): boolean;
/**
 * List all currently declared provider routes.
 * @param namespaceValue - current llm-pi-ai namespace value.
 * @returns provider keys, or an empty list for a missing providers object.
 */
export declare function installedRoutes(namespaceValue: unknown): readonly string[];
//# sourceMappingURL=presets.d.ts.map