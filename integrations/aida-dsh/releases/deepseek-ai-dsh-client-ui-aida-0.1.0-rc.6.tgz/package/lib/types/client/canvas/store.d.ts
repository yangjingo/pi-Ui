/**
 * AIDA Canvas store: the shared viewing state of the details-column panel and
 * the turn-tail chips. Created once in apply and handed to the three
 * session-scoped registrations, so opening a produced file from the chat tail
 * lands in the column. Editing buffers and fetched contents stay
 * component-local; the store carries only navigation state and the edit dirty
 * flag (plain JSON data, per the client stack rules). Column open/close is the
 * frame's details-track state (`ctx.layout`), not this store's.
 */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client';
import type { AidaCanvasActions, AidaCanvasState } from './contract.ts';
/** Empty canvas state (the panel resets to it on session switch). */
export declare const EMPTY_CANVAS_STATE: AidaCanvasState;
/**
 * Declares the per-session AIDA canvas state and write surface.
 * @returns the store handle shared by the details column, the header toggle, and the turn-tail chips.
 */
export declare function createAidaCanvasStore(): EngineStoreHandle<AidaCanvasState, AidaCanvasActions>;
//# sourceMappingURL=store.d.ts.map