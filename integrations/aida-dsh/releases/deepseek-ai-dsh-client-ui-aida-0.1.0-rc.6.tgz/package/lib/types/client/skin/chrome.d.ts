/**
 * AIDA chrome skin: small deterministic DOM adjustments the AIDA deployment
 * owns, driven by one document MutationObserver. Two behaviors:
 *
 * 1. The trajectory surface lives in the Canvas — the center-column
 *    trajectory view (its view-ring tab and the view content itself) and the
 *    session-header session-log download button are hidden; the Canvas
 *    trajectory tab hosts the trajectory and its own download button
 *    (rendered by the canvas component, not by this skin).
 *
 * 2. Project vocabulary — the sidebar workspace region and the hero
 *    workspace picker present the "Project" concept instead of "Workspace"
 *    (en/zh label replacement in text nodes and aria-label/title/placeholder
 *    attributes, scoped to the two seat slots). React skips text updates when
 *    its fiber props are unchanged, so the rewrite survives re-renders.
 *
 * All behaviors are pure functions over DOM nodes (unit-tested) plus a thin
 * observer that reconciles them; the observer is disposed with the plugin
 * fiber.
 */
/**
 * Apply the English/Chinese Workspace-to-Project vocabulary mapping.
 * @param value - visible text or accessible label.
 * @returns the mapped string.
 */
export declare function projectText(value: string): string;
/**
 * Check whether a label changes under the Project vocabulary.
 * @param value - visible text or accessible label.
 * @returns true when the mapping changes it.
 */
export declare function isProjectRename(value: string): boolean;
/** Seat slots the Project vocabulary rewrites. */
export declare const PROJECT_SCOPE_SLOTS: readonly ["sidebar.workspaces", "conversation.hero.workspace", "conversation.composer.bar"];
/**
 * Toggle an element's display state.
 * @param element - target element, when found.
 * @param hidden - requested hidden state.
 * @returns true when the inline style changed.
 */
export declare function setHidden(element: Element | null, hidden: boolean): boolean;
/**
 * Find the session header's view-ring tab list.
 * @param root - DOM subtree to query.
 * @returns the tab list, when mounted.
 */
export declare function findViewTablist(root: ParentNode): Element | null;
/**
 * Find session-log buttons in the session-header utilities seat.
 * @param root - DOM subtree to query.
 * @returns matching buttons; the Canvas toggle is excluded.
 */
export declare function findSessionLogButtons(root: ParentNode): readonly Element[];
/**
 * Rewrite Project vocabulary inside one seat slot.
 * @param slot - scoped slot element.
 * @returns true when a text node or label attribute changed.
 */
export declare function applyProjectVocabulary(slot: Element): boolean;
/**
 * Rewrite every in-scope seat once.
 * @param root - DOM subtree to query.
 * @returns true when any seat changed.
 */
export declare function applyProjectVocabularyOnce(root: ParentNode): boolean;
/**
 * Reconcile the whole chrome: hide the center-column trajectory surface (the
 * lone view-ring tab nav and any mounted trajectory view outside the canvas —
 * the canvas trajectory tab hosts the full view now) and the session-header
 * download button, and apply the Project vocabulary. The trajectory and its
 * download live in the Canvas.
 * @param root - document root.
 * @returns true when the DOM changed.
 */
export declare function reconcileChrome(root: ParentNode): boolean;
/**
 * Start the chrome skin: reconcile the hidden trajectory surface, the hidden
 * session-log header button, and the Project vocabulary on every DOM mutation
 * (microtask-batched).
 * @param root - document root to observe.
 * @returns disposer.
 */
export declare function startChromeSkin(root?: ParentNode): () => void;
//# sourceMappingURL=chrome.d.ts.map