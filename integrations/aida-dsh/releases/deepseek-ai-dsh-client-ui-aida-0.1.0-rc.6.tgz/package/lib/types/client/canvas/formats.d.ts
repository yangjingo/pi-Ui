/**
 * Canvas file-format dispatch: which renderer a file's preview uses, derived
 * from its extension. Markdown, HTML, Mermaid, SVG, JSON, and CSV get
 * dedicated renderers (and keep the plain textarea for editing); source-code
 * extensions render with syntax highlighting; everything else stays the
 * generic text pane.
 */
/** Preview/rendering formats the Canvas understands. */
export type CanvasFileFormat = 'markdown' | 'html' | 'mermaid' | 'svg' | 'json' | 'csv' | 'code' | 'text';
/**
 * Resolve the Canvas renderer for a file name.
 * @param name - file name or relative path.
 * @returns the extension-selected render format.
 */
export declare function formatOf(name: string): CanvasFileFormat;
/**
 * Whether a file name is an SVG source document.
 * @param name - file name or relative path.
 * @returns true for a `.svg` name (case-insensitive).
 */
export declare function isSvgName(name: string): boolean;
/**
 * Whether a file name is a tab-separated table.
 * @param name - file name or relative path.
 * @returns true for a `.tsv` name (case-insensitive).
 */
export declare function isTsvName(name: string): boolean;
/**
 * Resolve the shiki language hint for a source file.
 * @param name - file name or relative path.
 * @returns the grammar id, or undefined for an extension without a grammar.
 */
export declare function codeLangOf(name: string): string | undefined;
/** Formats with a dedicated renderer (editing still uses the plain textarea). */
export declare const FORMATTED_FORMATS: readonly CanvasFileFormat[];
//# sourceMappingURL=formats.d.ts.map