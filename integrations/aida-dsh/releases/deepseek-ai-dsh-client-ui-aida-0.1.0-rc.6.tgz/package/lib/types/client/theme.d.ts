import type { ThemeTokenOverrides } from '@deepseek-ai/dsh-client-ui-theme/client';
/** AIDA identity tokens adapted for the built-in light and dark palettes. */
export declare const AIDA_TOKENS: ThemeTokenOverrides;
//# sourceMappingURL=theme.d.ts.map