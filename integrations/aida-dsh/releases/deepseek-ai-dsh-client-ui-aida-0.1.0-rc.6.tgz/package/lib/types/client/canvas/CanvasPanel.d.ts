/**
 * AIDA Canvas column: the right-hand details track of the frame, rendered
 * side-by-side with the conversation (the frame reflows the center column —
 * no floating layer). Three tabs — Files (workspace tree + search + import +
 * rename/delete), Canvas (open file tabs with preview and editing), and
 * Trajectory (tool-step ledger with per-step details that render the shared
 * tool-output seat `conversation.details.tool`, produced-file chips that open
 * in the canvas). All workspace file transport arrives through the injected
 * ctx.workspaces verbs; the session's conversation facts arrive through the
 * standard `useSession` kit (the slot is session-scoped).
 */
import type { ConversationSnapshot, ToolResultNode } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
import type { AidaCanvasInjected } from './contract.ts';
import { createAidaCanvasStore } from './store.ts';
/** Full composed props of the details-column registration. */
export type AidaCanvasPanelProps = PropsRuntime<'details'> & PropsRenderSlots<'conversation.view'> & PropsStore<ReturnType<typeof createAidaCanvasStore>> & InjectFace<AidaCanvasInjected> & PropsLocale<typeof NS>;
/** Extract the follow-along file paths of a settled tool call (mutation cards only). */
export declare function producedPathsOf(node: ToolResultNode): readonly string[];
/**
 * Toggle the frame's maximized grid override. Maximized rewrites the grid to
 * `<sidebar> 0 <rest>` (the center track collapses to zero and the details
 * track — the canvas — spans the rest); the override rides a data attribute +
 * CSS variable, so AppFrame's own inline grid keeps tracking drags/resizes
 * underneath and restore is instant.
 * @param panel - the canvas section (frame lookup anchor).
 * @param maximized - whether to apply or clear the override.
 */
export declare function applyMaximizedGrid(panel: HTMLElement | null, maximized: boolean): void;
/** Render the Canvas column for the current session (the frame's details track). */
export declare function AidaCanvasPanel(props: AidaCanvasPanelProps): import("react").JSX.Element;
/** One trajectory row: a settled tool call. */
export interface TrajectoryStepRow {
    seq: number;
    callId: string;
    name: string;
    time: number;
    failed: boolean;
    paths: readonly string[];
}
/** Consecutive trajectory rows of one turn (null = steps with no turn location). */
export interface TrajectoryTurnGroup {
    turn: number | null;
    rows: readonly TrajectoryStepRow[];
}
/**
 * Build the callId→turn ledger from the chat node index: every materialized
 * tool chat node carries its conversation location, and the legacy
 * tool-result nodes share the same callId — no cross-package view-target
 * read needed (anchor seqs differ from result seqs, so callId is the key).
 * @param snapshot - the session's conversation snapshot.
 * @returns the callId→turn mapping for in-window tool nodes.
 */
export declare function trajectoryTurnLocations(snapshot: ConversationSnapshot): ReadonlyMap<string, number>;
/** Flatten the conversation's tool-result nodes into trajectory rows. */
export declare function trajectorySteps(snapshot: ConversationSnapshot | undefined): readonly TrajectoryStepRow[];
/**
 * Group the trajectory rows into consecutive turn runs (the turn/call
 * visualization: a turn header owns its calls; steps without a turn location
 * fall into null-turn groups rendered without a header).
 * @param snapshot - the session's conversation snapshot.
 * @returns the ordered turn groups.
 */
export declare function groupTrajectorySteps(snapshot: ConversationSnapshot | undefined): readonly TrajectoryTurnGroup[];
//# sourceMappingURL=CanvasPanel.d.ts.map