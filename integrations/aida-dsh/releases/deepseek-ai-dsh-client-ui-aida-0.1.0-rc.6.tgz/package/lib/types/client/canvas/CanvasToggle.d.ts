/**
 * AIDA Canvas toggle: an icon button in the session header's utilities row —
 * the same 28px circular icon-button style and icon size as the sidebar's
 * logo-row panel toggle, carrying the Canvas's own 2×2 grid mark (no text
 * label; the name rides tooltip/aria). Clicking opens the Canvas, the
 * right-hand details track of the frame, side-by-side with the conversation.
 * Column open/close is the frame's details-track state, so the button drives
 * `ctx.layout.openDetails` through the injected callback.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Injected open affordance of the header toggle. */
export interface CanvasToggleInjected {
    /** Open the Canvas column (the frame's details track). */
    openCanvas: () => void;
}
/** Full composed props of the header-utilities registration. */
export type AidaCanvasToggleProps = PropsRuntime<'conversation.session.header.utilities'> & InjectFace<CanvasToggleInjected> & PropsLocale<typeof NS>;
/** Render the header-utilities Canvas icon toggle (opens the right-hand column). */
export declare function AidaCanvasToggle({ openCanvas, t }: AidaCanvasToggleProps): import("react").JSX.Element;
//# sourceMappingURL=CanvasToggle.d.ts.map