/**
 * Mermaid diagram renderer for the AIDA Canvas: loads the mermaid runtime
 * lazily (dynamic import keeps it out of the main bundle) and renders the
 * source to an SVG. Mermaid validates color formats, so theme tokens are
 * resolved to literal colors before rendering. Errors fall back to the raw
 * source with the failure message, so a broken diagram never blanks the
 * canvas.
 */
export interface MermaidDiagramProps {
    /** Mermaid source text. */
    source: string;
}
/** Render a mermaid diagram from its source. */
export declare function MermaidDiagram({ source }: MermaidDiagramProps): import("react").JSX.Element;
//# sourceMappingURL=MermaidDiagram.d.ts.map