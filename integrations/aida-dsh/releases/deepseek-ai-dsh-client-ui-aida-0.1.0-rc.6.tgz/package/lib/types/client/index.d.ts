/**
 * AIDA deployment skin + Canvas: fixed palette, a single sidebar logo, and
 * the Canvas — a right-docked drawer in the
 * frame-wide overlay layer with a workspace file tree, preview, trajectory,
 * and upload. Removing the plugin restores every previous surface.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AidaKey } from './locales.ts';
export type { AidaKey } from './locales.ts';
export { AIDA_TOKENS } from './theme.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** AIDA brand and Canvas copy. */
        aida: AidaKey;
    }
}
/** Services required by the AIDA browser skin, Canvas, and intranet models. */
export declare const inject: string[];
/**
 * Activate the AIDA identity tokens, brand takeovers, and the Canvas drawer
 * while preserving the user's light, dark, or system preference.
 * @param ctx - client context carrying the theme, locale, sessions, and slot services.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map