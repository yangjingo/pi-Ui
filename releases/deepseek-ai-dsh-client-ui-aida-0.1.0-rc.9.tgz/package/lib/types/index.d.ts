/** Host loader entry for the installable AIDA Web bundle; behavior stays browser-only. */
/** Provides no host-side behavior (the browser entry carries all registrations). */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map