import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
/** Selector currency returned by each AIDA brand takeover. */
export interface AidaBrandMatch {
    /** Stable tag used only to select this plugin's visual replacement. */
    skin: 'aida';
}
/** Shared immutable match value for all AIDA chain entries. */
export declare const AIDA_BRAND_MATCH: AidaBrandMatch;
/** Properties for the reusable AIDA mark. */
export interface AidaMarkProps {
    /** CSS class applied to the SVG root. */
    className?: string | undefined;
    /** Square edge length in CSS pixels. */
    size?: number;
    /** Accessible name; omit when surrounding content already names the logo. */
    label?: string;
}
/**
 * Render the official AIDA symbol with its light/dark asset palette.
 * @param props - size, class, and optional accessible label.
 * @returns the vector mark.
 */
export declare function AidaMark({ className, size, label }: AidaMarkProps): import("react").JSX.Element;
/** Full expanded-sidebar chain props. */
export type AidaSidebarBrandProps = PropsRuntime<'sidebar.brand'> & {
    matched: AidaBrandMatch;
} & PropsLocale<typeof NS>;
/**
 * Replace the expanded sidebar's default product wordmark.
 * @param props - standard slot props and AIDA dictionary.
 * @returns the single AIDA logo requested for the main interface.
 */
export declare function AidaSidebarBrand({ t }: Pick<AidaSidebarBrandProps, 't'>): import("react").JSX.Element;
/** Full collapsed-sidebar chain props. */
export type AidaSidebarMarkProps = PropsRuntime<'sidebar.mark'> & {
    matched: AidaBrandMatch;
} & PropsLocale<typeof NS>;
/**
 * Replace the collapsed sidebar's default symbol.
 * @param props - standard slot props and AIDA dictionary.
 * @returns the compact AIDA mark.
 */
export declare function AidaSidebarMark({ t }: Pick<AidaSidebarMarkProps, 't'>): import("react").JSX.Element;
//# sourceMappingURL=AidaBrand.d.ts.map