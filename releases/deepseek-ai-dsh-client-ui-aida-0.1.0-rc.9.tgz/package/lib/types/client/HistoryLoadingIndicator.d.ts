import type { HistoryLoadingProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/**
 * Render the AIDA history-open signal as two counter-rotating circular rails.
 * @param props - localized label and standard Session slot currency.
 * @returns the accessible loading indicator.
 */
export declare function AidaHistoryLoadingIndicator({ label }: HistoryLoadingProps): import("react").JSX.Element;
//# sourceMappingURL=HistoryLoadingIndicator.d.ts.map