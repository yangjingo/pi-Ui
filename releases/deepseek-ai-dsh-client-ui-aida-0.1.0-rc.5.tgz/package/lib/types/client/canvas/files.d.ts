/**
 * Pure workspace-file helpers for the AIDA Canvas: tree flattening, query
 * filtering, path utilities, and binary payload conversion. No React, no
 * transport — the panel and the tree render from these shapes only.
 */
import type { WorkspaceFileKind, WorkspaceFileNode } from '@deepseek-ai/dsh-api-remotes/client';
/** Flatten a listing tree to its leaf files. */
export declare function listFiles(nodes: readonly WorkspaceFileNode[], result?: WorkspaceFileNode[]): WorkspaceFileNode[];
/** Count files (leaves) under a listing. */
export declare function countFiles(nodes: readonly WorkspaceFileNode[]): number;
/** Last path segment. */
export declare function basename(path: string): string;
/** Parent directory of a path ('工作区' for a top-level file). */
export declare function parentPath(path: string): string;
/** Case-insensitive subtree filter; matching folders are forced open. */
export declare function filterFileTree(nodes: readonly WorkspaceFileNode[], query: string): WorkspaceFileNode[];
/** Whether a file is editable as UTF-8 text in the canvas. */
export declare function isEditableText(node: WorkspaceFileNode | undefined): boolean;
/** Human-readable kind label used for icons and empty states. */
export declare function kindLabel(kind: WorkspaceFileKind): string;
/** Base64 → binary Blob (browser only). */
export declare function base64ToBlob(base64: string, contentType: string): Blob;
/** Bytes → base64 in chunks (browser-safe; no Buffer dependency). */
export declare function bytesToBase64(bytes: Uint8Array): string;
/** Trigger a browser download for a blob. */
export declare function saveBlobAs(blob: Blob, filename: string): void;
//# sourceMappingURL=files.d.ts.map