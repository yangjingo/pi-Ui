/**
 * Canvas file-format dispatch: which renderer a text file's preview uses,
 * derived from its extension. Markdown, HTML, and Mermaid get dedicated
 * renderers (and keep the plain textarea for editing); everything else stays
 * the generic text pane.
 */
/** Preview/rendering formats the Canvas understands. */
export type CanvasFileFormat = 'markdown' | 'html' | 'mermaid' | 'text';
/** Render format for one file name (the extension decides). */
export declare function formatOf(name: string): CanvasFileFormat;
/** Formats with a dedicated renderer (editing still uses the plain textarea). */
export declare const FORMATTED_FORMATS: readonly CanvasFileFormat[];
//# sourceMappingURL=formats.d.ts.map