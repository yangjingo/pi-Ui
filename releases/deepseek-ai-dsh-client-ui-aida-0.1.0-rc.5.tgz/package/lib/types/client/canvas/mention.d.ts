/**
 * Workspace-file mention: the AIDA '@' reference source and the canvas-side
 * injection helpers. Typing `@` in the composer lists the current session's
 * project files; a pick inserts a `@path` chip whose model form embeds the
 * file content at submit. The Canvas drawer (root scope) cannot see the
 * session-scoped input actions, so its 引用 actions route through the
 * conversation service's per-session input shell the same way the pick
 * pipeline does.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { InputTriggerSource, ReferenceInsert } from '@deepseek-ai/dsh-client-ui-input-trigger/client';
import type { WorkspaceFileNode } from '@deepseek-ai/dsh-api-remotes/client';
/** Source name of the workspace-file '@' mention (renders as the menu group label). */
export declare const FILE_MENTION_SOURCE = "\u6587\u4EF6";
/** Max characters embedded for one file mention; longer files are cut with a marker. */
export declare const MAX_MENTION_CHARS: number;
/** Flatten a recursive listing to the relative paths of text files, in tree order. */
export declare function flattenTextFiles(nodes: readonly WorkspaceFileNode[]): string[];
/** The model representation of one file mention: content embedded, capped. */
export declare function fileModelForm(path: string, content: string): string;
/** The literal quoted block injected for a canvas selection, labeled with its source path. */
export declare function quoteBlock(path: string, text: string): string;
/** Encode one mention ref from its workspace root and relative path. */
export declare function mentionRef(root: string, path: string): string;
/** Split a mention ref back into its workspace root and relative path. */
export declare function splitMentionRef(ref: string): {
    root: string;
    path: string;
};
/** A mention insert ready for the input pipeline (the ref is root-qualified so the codec needs no session). */
export declare function fileReference(root: string, path: string): ReferenceInsert;
/**
 * Insert a workspace-file mention chip at the end of the current session's
 * composer draft. The span CAS uses the shell's live revision, so a
 * concurrent keystroke makes the insert a no-op rather than a corruption.
 * @param ctx - client root context.
 * @param path - POSIX-relative path within the session's workspace root.
 * @returns whether the chip was accepted by the input machine.
 */
export declare function mentionFileIntoComposer(ctx: ClientContext, path: string): boolean;
/**
 * Inject a quoted selection (labeled with its source path) into the current
 * session's composer draft as literal text.
 * @param ctx - client root context.
 * @param path - POSIX-relative source path of the selection.
 * @param text - the selected text, quoted verbatim.
 * @returns whether the draft accepted the write.
 */
export declare function quoteSelectionIntoComposer(ctx: ClientContext, path: string, text: string): boolean;
/**
 * The '@' workspace-file source: candidates are the current session's text
 * files, picks insert {@link fileReference} chips, and the codec embeds the
 * file content at submit. The lexicon roll (for plain-text decoration of
 * persisted drafts) is warmed per session from the same listing.
 * @param ctx - client root context (sessions + workspaces faces).
 */
export declare function createFileMentionSource(ctx: ClientContext): InputTriggerSource;
//# sourceMappingURL=mention.d.ts.map