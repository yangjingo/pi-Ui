/**
 * Accessible recursive file tree for the AIDA Canvas Files tab: roving
 * tabindex, folder toggle, active-file highlighting, and search-result
 * highlighting. A trimmed port of the Pi Canvas tree, using only the
 * workspace-file node shape.
 */
import type { KeyboardEvent as ReactKeyboardEvent, FocusEvent as ReactFocusEvent, ReactNode } from 'react';
import type { WorkspaceFileNode } from '@deepseek-ai/dsh-api-remotes/client';
/** Move focus along the visible tree rows (roving tabindex). */
export declare function navigateFileTree(event: ReactKeyboardEvent<HTMLDivElement>): void;
/** Keep exactly one visible row focusable. */
export declare function keepTreeRovingFocus(event: ReactFocusEvent<HTMLDivElement>): void;
export interface FileTreeProps {
    /** Root nodes to render (already filtered). */
    list: readonly WorkspaceFileNode[];
    /** Depth offset (root rows are depth 0). */
    depth?: number;
    /** Path of the active canvas file. */
    activePath: string | null;
    /** Search-highlighted path. */
    highlighted: string | null;
    /** Folder paths the user collapsed (default: all folders open). */
    collapsed: ReadonlySet<string>;
    /** Folder open/close toggle. */
    onToggle: (node: WorkspaceFileNode) => void;
    /** Open a file in the canvas. */
    onOpen: (node: WorkspaceFileNode) => void;
    /** Per-leaf action slot rendered beside the row (rename/delete menu). */
    renderRowActions: ((node: WorkspaceFileNode) => ReactNode) | undefined;
}
/** Recursively render one level of the tree. */
export declare function FileTree(props: FileTreeProps): import("react").JSX.Element;
//# sourceMappingURL=FileTree.d.ts.map