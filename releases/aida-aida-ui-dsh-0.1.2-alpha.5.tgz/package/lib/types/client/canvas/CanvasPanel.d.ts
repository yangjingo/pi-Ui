/**
 * AIDA Canvas column: the right-hand details track of the frame, rendered
 * side-by-side with the conversation (the frame reflows the center column —
 * no floating layer). Three tabs — Files (workspace tree + search + import +
 * rename/delete), Canvas (open file tabs with preview and editing), and
 * Trajectory (the original DSH TrajectoryView, relocated without a fork).
 * All workspace file transport arrives through the injected
 * ctx.workspaces verbs; the session's conversation facts arrive through the
 * standard `useSession` kit (the slot is session-scoped).
 */
import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
import type { AidaCanvasInjected } from './contract.ts';
import { createAidaCanvasStore } from './store.ts';
/** Full composed props of the details-column registration. */
export type AidaCanvasPanelProps = PropsRuntime<'details'> & PropsStore<ReturnType<typeof createAidaCanvasStore>> & InjectFace<AidaCanvasInjected> & PropsLocale<typeof NS>;
/** Tool-result facts consumed by produced-file extraction (0.1.1 and 0.1.2 shapes). */
interface ToolResultLike {
    readonly call?: {
        name: string;
        argsRaw: string;
    } | null;
    readonly callView?: {
        card: string;
        locations?: ReadonlyArray<{
            path: string;
        }>;
    } | null;
    readonly resultView?: {
        card: string;
        path?: string;
        diffs?: ReadonlyArray<{
            path: string;
        }>;
    } | null;
}
/** Extract the follow-along file paths of a settled mutation call. */
export declare function producedPathsOf(node: ToolResultLike): readonly string[];
/**
 * Toggle the frame's maximized grid override. Maximized rewrites the grid to
 * `<sidebar> 0 <rest>` (the center track collapses to zero and the details
 * track — the canvas — spans the rest); the override rides a data attribute +
 * CSS variable, so AppFrame's own inline grid keeps tracking drags/resizes
 * underneath and restore is instant.
 * @param panel - the canvas section (frame lookup anchor).
 * @param maximized - whether to apply or clear the override.
 */
export declare function applyMaximizedGrid(panel: HTMLElement | null, maximized: boolean): void;
/** Render the Canvas column for the current session (the frame's details track). */
export declare function AidaCanvasPanel(props: AidaCanvasPanelProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=CanvasPanel.d.ts.map