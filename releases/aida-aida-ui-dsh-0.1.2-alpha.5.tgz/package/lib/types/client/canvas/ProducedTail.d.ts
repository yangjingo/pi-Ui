/**
 * AIDA Canvas turn-tail chips: the produced-files row under a closing
 * assistant message. The chain selector reads the deliverables location data
 * the ui-deliverables definition publishes (key 'deliverables' on the Turn
 * data map — the documented location-data channel), and the chips open the
 * file in the AIDA Canvas column instead of the Host's OS opener. When the
 * turn produced nothing the selector declines and the shipped row still
 * renders.
 */
import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { TurnTailOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import { NS } from '../locales.ts';
import { createAidaCanvasStore } from './store.ts';
/** Injected open affordance of the turn-tail chips. */
export interface ProducedTailInjected {
    /** Open the Canvas column (the frame's details track). */
    openCanvas: () => void;
}
/** Produced-path facts the ui-deliverables definition publishes per turn. */
interface AidaDeliverablesTurnData {
    readonly produced: readonly {
        readonly path: string;
        readonly seq: number;
    }[];
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ConversationTurnDataMap {
        /** Successful mutation paths accumulated in this Turn (ui-deliverables publishes it). */
        deliverables: AidaDeliverablesTurnData;
    }
}
/** Full composed props of the turn-tail registration. */
export type ProducedTailProps = PropsRuntime<'conversation.chat.turnTail'> & Pick<TurnTailOwnerProps, 'turn' | 'seq'> & {
    matched: readonly string[];
} & PropsStore<ReturnType<typeof createAidaCanvasStore>> & InjectFace<ProducedTailInjected> & PropsLocale<typeof NS>;
/**
 * Claim the turn-tail chain only when the closing turn produced files.
 * @param owner - Turn-tail owner currency for the closing assistant.
 * @returns Produced paths as the component's match, or null to decline.
 */
export declare function selectAidaProducedFiles(owner: TurnTailOwnerProps): readonly string[] | null;
/** Render the produced-files chips of one turn, opening into the Canvas column. */
export declare function ProducedTail({ matched: paths, actions, openCanvas, t }: ProducedTailProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ProducedTail.d.ts.map