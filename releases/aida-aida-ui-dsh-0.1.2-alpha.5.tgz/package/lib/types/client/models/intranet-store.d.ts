/**
 * Intranet-models install state: joins the `llm-pi-ai` settings namespace
 * with the AIDA preset roster and performs the one-click install write.
 * Mirrors the Models page's custom-provider card: one `settings.mutate` sets
 * the whole profile at `providers.<route>` with the read-time revision, so a
 * route another surface declared meanwhile is a `settings-conflict` refusal
 * rather than a silent overwrite.
 */
import type { ClientRemote, SettingsNamespaceView } from '@deepseek-ai/dsh-api-remotes/client';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-store';
import { type IntranetModelPreset } from './presets.ts';
/** State rendered by the intranet-models section. */
export interface IntranetModelsState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    error: string | null;
    /** Whether the settings provider accepts writes. */
    writable: boolean;
    /** Revision of the namespace the current view was read at (write guard). */
    revision: number | undefined;
    /** Route ids already declared. */
    taken: readonly string[];
    /** Route currently being installed. */
    busy: string | null;
}
/**
 * Find the llm-pi-ai namespace in a settings description.
 * @param namespaces - described settings namespaces.
 * @returns the provider namespace, when present.
 */
export declare function providerNamespaceView(namespaces: readonly SettingsNamespaceView[]): SettingsNamespaceView | undefined;
/** Coordinates the install reads/writes and their store. */
export declare class IntranetModelsController {
    private readonly api;
    /** uSES-safe state source shared by the registered section. */
    readonly store: SnapshotStore<IntranetModelsState>;
    private generation;
    /**
     * @param api - settings wire face used for durable reads and writes.
     */
    constructor(api: Pick<ClientRemote, 'settings'>);
    /** Load the namespace view and project the preset install states. */
    load(): Promise<void>;
    /**
     * Install one preset into the llm-pi-ai namespace.
     * @param preset - the preset to install.
     * @returns a failure message, or undefined on success.
     */
    install(preset: IntranetModelPreset): Promise<string | undefined>;
}
//# sourceMappingURL=intranet-store.d.ts.map