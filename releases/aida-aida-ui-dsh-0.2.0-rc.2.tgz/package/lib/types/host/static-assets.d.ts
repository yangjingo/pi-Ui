/** Safe same-origin static asset route for the AIDA deployment skin. */
import type { IncomingMessage, ServerResponse } from 'node:http';
/** Prefix owned by this plugin. A plugin-owned prefix cannot shadow DSH routes. */
export declare const AIDA_ASSETS_ROUTE = "/aida-ui-assets";
export type StaticAssetResolution = {
    readonly ok: true;
    readonly file: string;
    readonly contentType: string;
    readonly bytes: number;
} | {
    readonly ok: false;
    readonly status: 404;
};
/**
 * Resolve one AIDA asset request below {@link AIDA_ASSETS_ROUTE}.
 * @param assetRoot absolute package `assets/` directory.
 * @param requestUrl raw Node request URL (query strings are ignored).
 * @returns a file descriptor, or a stable 404 for traversal/unknown assets.
 */
export declare function resolveAidaAsset(assetRoot: string, requestUrl: string | undefined): Promise<StaticAssetResolution>;
/**
 * Create the prefix handler serving only bundled AIDA artwork.
 * @param assetRoot absolute package `assets/` directory.
 * @returns async Node HTTP handler.
 */
export declare function createAidaAssetsHandler(assetRoot: string): (req: IncomingMessage, res: ServerResponse) => Promise<void>;
//# sourceMappingURL=static-assets.d.ts.map