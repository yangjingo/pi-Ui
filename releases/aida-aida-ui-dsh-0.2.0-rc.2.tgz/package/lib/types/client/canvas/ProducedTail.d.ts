/**
 * AIDA Canvas turn-tail chips: the produced-files row under a closing
 * assistant message. The `conversation.chat.turnTail` slot is a list in
 * dsh 0.2.0, so the component itself reads the deliverables location data
 * the ui-deliverables definition publishes (key 'deliverables' on the Turn
 * data map — the documented location-data channel) and renders nothing when
 * the turn produced nothing, letting the shipped row show instead. The chips
 * open the file in the AIDA Canvas rightbar tab instead of the Host's OS
 * opener.
 */
import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { TurnTailOwnerProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import { NS } from '../locales.ts';
import { createAidaCanvasStore } from './store.ts';
/** Injected open affordance of the turn-tail chips. */
export interface ProducedTailInjected {
    /** Open the Canvas rightbar tab. */
    openCanvas: () => void;
}
/** Produced-path facts the ui-deliverables definition publishes per turn. */
interface AidaDeliverablesTurnData {
    readonly produced: readonly {
        readonly path: string;
        readonly seq: number;
    }[];
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ConversationTurnDataMap {
        /** Successful mutation paths accumulated in this Turn (ui-deliverables publishes it). */
        deliverables: AidaDeliverablesTurnData;
    }
}
/** Full composed props of the turn-tail registration. */
export type ProducedTailProps = PropsRuntime<'conversation.chat.turnTail'> & TurnTailOwnerProps & PropsStore<ReturnType<typeof createAidaCanvasStore>> & InjectFace<ProducedTailInjected> & PropsLocale<typeof NS>;
/**
 * Collect the produced paths of the closing turn, or null when it produced
 * nothing (the component then renders nothing).
 * @param owner - Turn-tail owner currency for the closing assistant.
 * @returns Produced paths, or null when the turn produced no files.
 */
export declare function selectAidaProducedFiles(owner: TurnTailOwnerProps): readonly string[] | null;
/** Render the produced-files chips of one turn, opening into the Canvas tab. */
export declare function ProducedTail({ turn, seq, actions, openCanvas, t }: ProducedTailProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=ProducedTail.d.ts.map