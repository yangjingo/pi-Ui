/** Host route for the standalone AIDA Workspace Canvas. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "client-ui-aida";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map