import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { HeroBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import { NS } from './locales.ts';
/** Full AIDA new-session brand props. */
export type AidaHeroBrandProps = HeroBrandMarkOwnerProps & PropsLocale<typeof NS>;
/**
 * Render the AIDA logo, localized slogan, and release-stage label.
 * @param props - owner-provided localized copy plus the AIDA locale seat.
 * @returns the centered new-session brand lockup.
 */
export declare function AidaHeroBrand({ size, className, t }: AidaHeroBrandProps): import("react").JSX.Element;
//# sourceMappingURL=AidaHeroBrand.d.ts.map