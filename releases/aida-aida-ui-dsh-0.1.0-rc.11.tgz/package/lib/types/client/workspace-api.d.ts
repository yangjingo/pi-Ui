/** Browser client for the AIDA plugin's private same-origin Workspace route. */
import { type WorkspaceFileListing, type WorkspaceFileRead, type WorkspaceFileWrite } from '../workspace-protocol.ts';
export declare const aidaWorkspaceApi: {
    listFiles: (root: string, signal?: AbortSignal) => Promise<WorkspaceFileListing>;
    readFile: (root: string, path: string, opts?: {
        offset?: number;
        maxBytes?: number;
    }, signal?: AbortSignal) => Promise<WorkspaceFileRead>;
    writeFile: (root: string, path: string, input: {
        content?: string;
        base64?: string;
    }, signal?: AbortSignal) => Promise<WorkspaceFileWrite>;
    renameFile: (root: string, path: string, nextName: string, signal?: AbortSignal) => Promise<WorkspaceFileWrite>;
    moveFile: (root: string, path: string, targetPath: string, signal?: AbortSignal) => Promise<WorkspaceFileWrite>;
    deleteFile: (root: string, path: string, signal?: AbortSignal) => Promise<WorkspaceFileWrite>;
};
//# sourceMappingURL=workspace-api.d.ts.map