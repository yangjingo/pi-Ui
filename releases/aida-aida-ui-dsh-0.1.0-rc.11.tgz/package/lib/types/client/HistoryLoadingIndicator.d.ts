export interface HistoryLoadingProps {
    label: string;
}
/**
 * Render the AIDA history-open signal as two counter-rotating circular rails.
 * @param props - localized label and standard Session slot currency.
 * @returns the accessible loading indicator.
 */
export declare function AidaHistoryLoadingIndicator({ label }: HistoryLoadingProps): import("react").JSX.Element;
//# sourceMappingURL=HistoryLoadingIndicator.d.ts.map