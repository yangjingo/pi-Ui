/**
 * Accessible recursive file tree for the AIDA Canvas Files tab: roving
 * tabindex, folder toggle, active-file highlighting, and search-result
 * highlighting. A trimmed port of the Pi Canvas tree, using only the
 * workspace-file node shape.
 */
import type { KeyboardEvent as ReactKeyboardEvent, FocusEvent as ReactFocusEvent, ReactNode } from 'react';
import type { WorkspaceFileNode } from '../../workspace-protocol.ts';
/** The dataTransfer type carrying a dragged file's relative path. */
export declare const FILE_DRAG_TYPE = "application/x-aida-file-path";
/** Move focus along the visible tree rows (roving tabindex). */
export declare function navigateFileTree(event: ReactKeyboardEvent<HTMLDivElement>): void;
/** Keep exactly one visible row focusable. */
export declare function keepTreeRovingFocus(event: ReactFocusEvent<HTMLDivElement>): void;
export interface FileTreeProps {
    /** Root nodes to render (already filtered). */
    list: readonly WorkspaceFileNode[];
    /** Depth offset (root rows are depth 0). */
    depth?: number;
    /** Path of the active canvas file. */
    activePath: string | null;
    /** Search-highlighted path. */
    highlighted: string | null;
    /** Folder paths the user collapsed (default: all folders open). */
    collapsed: ReadonlySet<string>;
    /** Paths of rows selected for batch actions (file leaves). */
    selected: ReadonlySet<string>;
    /** Folder open/close toggle. */
    onToggle: (node: WorkspaceFileNode) => void;
    /** Open a file in the canvas (a plain leaf click). */
    onOpen: (node: WorkspaceFileNode) => void;
    /** Toggle a leaf into/out of the batch selection (Ctrl/⌘+click). */
    onSelectToggle: (node: WorkspaceFileNode) => void;
    /** Select the leaf range from the selection anchor (Shift+click). */
    onSelectRange: (node: WorkspaceFileNode) => void;
    /** Per-leaf action slot rendered beside the row (rename/delete menu). */
    renderRowActions: ((node: WorkspaceFileNode) => ReactNode) | undefined;
    /** Right-click on a row: open its action menu (menu state owned by the caller). */
    onRowContextMenu?: ((node: WorkspaceFileNode) => void) | undefined;
    /** Move a dragged file into a folder (`targetDir` '' = the workspace root). */
    onDropFile: (path: string, targetDir: string) => void;
}
/** Recursively render one level of the tree. */
export declare function FileTree(props: FileTreeProps): import("react").JSX.Element;
//# sourceMappingURL=FileTree.d.ts.map