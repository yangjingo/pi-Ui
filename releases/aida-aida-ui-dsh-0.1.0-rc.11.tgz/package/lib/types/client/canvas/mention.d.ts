/**
 * Workspace-file mention: the AIDA '@' reference source and the canvas-side
 * injection helpers. Typing `@` in the composer lists the current session's
 * project files; a pick inserts a `@path` chip whose model form embeds the
 * file content at submit. The Canvas drawer (root scope) cannot see the
 * session-scoped input actions, so its 引用 actions route through the
 * conversation service's per-session input shell the same way the pick
 * pipeline does.
 */
import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client';
import type { InputTriggerSource, ReferenceInsert } from '@deepseek-ai/dsh-client-ui-input-trigger/client';
import type { WorkspaceFileNode } from '../../workspace-protocol.ts';
import { aidaWorkspaceApi } from '../workspace-api.ts';
/** Source name of the workspace-file '@' mention (renders as the menu group label). */
export declare const FILE_MENTION_SOURCE = "\u6587\u4EF6";
/** Max characters embedded for one file mention; longer files are cut with a marker. */
export declare const MAX_MENTION_CHARS: number;
/**
 * Flatten a recursive listing to text-file paths in tree order.
 * @param nodes - recursive Workspace nodes.
 * @returns relative paths of text files.
 */
export declare function flattenTextFiles(nodes: readonly WorkspaceFileNode[]): string[];
/**
 * Build the model representation of one file mention.
 * @param path - Workspace-relative source path.
 * @param content - decoded source text.
 * @returns a capped, labeled file block.
 */
export declare function fileModelForm(path: string, content: string): string;
/**
 * Build a literal quoted block for a Canvas selection.
 * @param path - Workspace-relative source path.
 * @param text - selected text.
 * @returns a source-labeled Markdown quote.
 */
export declare function quoteBlock(path: string, text: string): string;
/**
 * Encode a root-qualified mention reference.
 * @param root - absolute Workspace root.
 * @param path - Workspace-relative file path.
 * @returns the opaque reference string.
 */
export declare function mentionRef(root: string, path: string): string;
/**
 * Decode a root-qualified mention reference.
 * @param ref - opaque reference string.
 * @returns its Workspace root and relative path.
 */
export declare function splitMentionRef(ref: string): {
    root: string;
    path: string;
};
/**
 * Build a mention insertion for the input pipeline.
 * @param root - absolute Workspace root.
 * @param path - Workspace-relative file path.
 * @returns a root-qualified reference insertion.
 */
export declare function fileReference(root: string, path: string): ReferenceInsert;
/**
 * Last accepted mention per session: the ref plus the draft revision right
 * after the insert, so a consecutive mention of the same file (nothing typed
 * or inserted in between) is a no-op instead of a duplicate chip. Exported
 * for the package's own tests, which clear it between cases.
 */
export declare const lastMentionBySession: Map<SessionId, {
    ref: string;
    rev: number;
}>;
/**
 * Insert a workspace-file mention chip at the end of the current session's
 * composer draft. The span CAS uses the shell's live revision, so a
 * concurrent keystroke makes the insert a no-op rather than a corruption.
 * A consecutive mention of the same file (no draft change since the last
 * accepted insert) is a no-op that still reports success.
 * @param ctx - client root context.
 * @param path - POSIX-relative path within the session's workspace root.
 * @returns whether the chip was accepted by the input machine.
 */
export declare function mentionFileIntoComposer(ctx: ClientContext, path: string): boolean;
/**
 * Inject a quoted selection (labeled with its source path) into the current
 * session's composer draft as literal text.
 * @param ctx - client root context.
 * @param path - POSIX-relative source path of the selection.
 * @param text - the selected text, quoted verbatim.
 * @returns whether the draft accepted the write.
 */
export declare function quoteSelectionIntoComposer(ctx: ClientContext, path: string, text: string): boolean;
/**
 * The '@' workspace-file source: candidates are the current session's text
 * files, picks insert {@link fileReference} chips, and the codec embeds the
 * file content at submit. The lexicon roll (for plain-text decoration of
 * persisted drafts) is warmed per session from the same listing.
 * @param ctx - client root context carrying the session face.
 * @param workspace - workspace-file transport; the plugin supplies its HTTP client.
 * @returns the Workspace-file trigger source.
 */
export declare function createFileMentionSource(ctx: ClientContext, workspace?: Pick<typeof aidaWorkspaceApi, 'listFiles' | 'readFile'>): InputTriggerSource;
//# sourceMappingURL=mention.d.ts.map