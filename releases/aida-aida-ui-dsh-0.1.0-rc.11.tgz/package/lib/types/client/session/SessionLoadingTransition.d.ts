export interface SessionLoadingTransitionProps {
    /** Whether the active session is replaying its persisted history. */
    loading: boolean;
    /** Localized status announced to assistive technology. */
    label: string;
}
/**
 * Bridge the session replay state into the transcript flow without replacing
 * DSH's chat implementation. The header utility is session-scoped and stays
 * mounted for the whole replay, while the portal keeps the visual transition
 * colocated with the content it reveals.
 */
export declare function SessionLoadingTransition({ loading, label }: SessionLoadingTransitionProps): import("react").ReactPortal | null;
//# sourceMappingURL=SessionLoadingTransition.d.ts.map