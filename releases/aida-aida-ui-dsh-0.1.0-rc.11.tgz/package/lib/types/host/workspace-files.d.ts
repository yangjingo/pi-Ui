/**
 * Workspace file service for the Canvas host wire (host.listFiles /
 * host.readFile / host.writeFile). One root per call, resolved by the client
 * from the session's workspace path; every operation canonicalizes the root
 * and the target and rejects paths that escape it. The service mirrors the
 * semantics of the Pi Canvas FileHarness it ports: recursive capped listing
 * that skips hidden and tooling entries, text-vs-binary preview decisions,
 * and size caps on reads and writes. It uses plain node:fs — the API proxy
 * does not require the fs capability row — and throws typed
 * {@link WorkspaceFileError} values that the proxy maps onto wire codes.
 */
import type { WorkspaceFileListing, WorkspaceFileRead, WorkspaceFileWrite } from '../workspace-protocol.ts';
/** Recursive listing cap: total files (files + folders) visited. */
export declare const MAX_LIST_FILES = 500;
/** Recursive listing depth cap. */
export declare const MAX_LIST_DEPTH = 24;
/** Total bytes of file content the listing may account for. */
export declare const MAX_LIST_TOTAL_BYTES: number;
/** Per-file text preview cap (also the text read slice cap). */
export declare const MAX_TEXT_READ_BYTES: number;
/** Per-file binary preview cap (image/PDF/office). */
export declare const MAX_BINARY_READ_BYTES: number;
/** Text write cap. */
export declare const MAX_TEXT_WRITE_BYTES: number;
/** Binary write cap (base64-decoded bytes). */
export declare const MAX_BINARY_WRITE_BYTES: number;
/** Wire error code of one typed workspace-file failure. */
export type WorkspaceFileErrorCode = 'workspace-invalid-path' | 'workspace-root-missing' | 'workspace-file-not-found' | 'workspace-file-unreadable' | 'workspace-file-too-large' | 'workspace-path-outside-root' | 'workspace-write-invalid' | 'workspace-write-failed';
/** Typed failure the proxy maps onto the wire vocabulary. */
export declare class WorkspaceFileError extends Error {
    readonly code: WorkspaceFileErrorCode;
    readonly details: {
        path?: string;
        totalBytes?: number;
        maxBytes?: number;
        reason?: string;
    };
    constructor(code: WorkspaceFileErrorCode, message: string, details?: {
        path?: string;
        totalBytes?: number;
        maxBytes?: number;
        reason?: string;
    });
}
/** Registered-Workspace filesystem operations used by the Canvas wire. */
export declare class WorkspaceFiles {
    private readonly registeredRoots;
    /**
     * @param registeredRoots - current canonical Workspace roots. File calls
     * are accepted only for one of these roots; a browser payload cannot turn
     * this service into an arbitrary host-filesystem reader.
     */
    constructor(registeredRoots: () => readonly string[]);
    /** Resolve and authorize one requested Workspace root. */
    private root;
    /**
     * Recursively list one workspace root (capped, hidden/tooling entries skipped).
     * @param root - absolute workspace root to list.
     * @returns the listing; `truncated` reports a cap stop.
     */
    list(root: string): WorkspaceFileListing;
    /**
     * Read one workspace file for preview.
     * @param root - absolute workspace root.
     * @param path - POSIX-relative path within the root.
     * @param opts - optional slice bounds (offset/maxBytes for text files).
     * @returns the decoded text slice or base64 binary payload.
     */
    read(root: string, path: string, opts?: {
        offset?: number;
        maxBytes?: number;
    }): WorkspaceFileRead;
    /**
     * Write one workspace file (text or base64 binary), creating parents.
     * @param root - absolute workspace root.
     * @param path - POSIX-relative path within the root.
     * @param input - exactly one of `content` (UTF-8 text) or `base64` (binary).
     * @returns the resolved relative path.
     */
    write(root: string, path: string, input: {
        content?: string;
        base64?: string;
    }): WorkspaceFileWrite;
    /**
     * Rename one workspace file within the root (new name only — the parent
     * stays the source's parent). Fails when the target already exists.
     * @param root - absolute workspace root.
     * @param path - POSIX-relative source path.
     * @param nextName - single non-blank path segment.
     * @returns the resolved relative path.
     */
    rename(root: string, path: string, nextName: string): WorkspaceFileWrite;
    /**
     * Delete one workspace file.
     * @param root - absolute workspace root.
     * @param path - POSIX-relative path.
     * @returns the deleted relative path.
     */
    remove(root: string, path: string): WorkspaceFileWrite;
    /**
     * Move one workspace file to a new location within the root (a full
     * relative destination; the destination's parent must already exist).
     * Fails when the destination exists or equals the source.
     * @param root - absolute workspace root.
     * @param path - POSIX-relative source path.
     * @param targetPath - POSIX-relative destination path.
     * @returns the resolved relative destination path.
     */
    move(root: string, path: string, targetPath: string): WorkspaceFileWrite;
}
//# sourceMappingURL=workspace-files.d.ts.map