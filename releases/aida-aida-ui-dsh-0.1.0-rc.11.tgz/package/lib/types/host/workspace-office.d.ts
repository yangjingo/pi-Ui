/**
 * Office Open XML preview extraction for the Canvas wire (host side). Ported
 * from the Pi Canvas file harness: Word/PPT become markdown-ish text, Excel
 * workbooks become a JSON sheet table the browser renders. Binary only —
 * the caller reads the file bytes and passes them here.
 */
/** Office Open XML extensions with an in-preview text path. */
export declare const OFFICE_EXTENSIONS: Set<string>;
/** Excel workbook preview shape the browser sheet renderer consumes. */
export interface OfficeWorkbookPreview {
    __office: 'workbook';
    sheets: Array<{
        name: string;
        rows: string[][];
    }>;
}
/**
 * Check whether a file has a supported Office Open XML extension.
 * @param name - file name or relative path.
 * @returns true when semantic preview extraction is supported.
 */
export declare function isOfficeFile(name: string): boolean;
/**
 * Check whether an Office file is an Excel workbook.
 * @param name - file name or relative path.
 * @returns true for supported workbook extensions.
 */
export declare function isOfficeWorkbookFile(name: string): boolean;
/**
 * Extract a semantic text preview of an Office Open XML document.
 * @param name - file name (extension selects the extractor).
 * @param data - raw file bytes.
 * @returns Word/PPT as markdown-ish text, Excel as a JSON sheet table.
 */
export declare function extractOfficePreview(name: string, data: Uint8Array): string;
//# sourceMappingURL=workspace-office.d.ts.map